<?php

include 'header.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title>Nandi Hills</title>
</head>
<body>
	<h1>Nandi Hills</h1>
</body>
</html>
<?php
include 'footer.php';
?>