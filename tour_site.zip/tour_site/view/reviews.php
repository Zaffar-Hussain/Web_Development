<?php

include 'header.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title>CarHub >> REVIEWS</title>
</head>
<body>

	<h1>This is reviews page</h1>

</body>
</html>
<?php
include 'footer.php';
?>