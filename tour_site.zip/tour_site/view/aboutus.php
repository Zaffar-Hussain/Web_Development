<?php

include 'header.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title>CarHub >> ABOUT US</title>
</head>
<body>

	<h1>This is about us page</h1>

</body>
</html>
<?php
include 'footer.php';
?>